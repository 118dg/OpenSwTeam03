import React from 'react';
import './LoginModal.css';
import {Link} from "react-router-dom";
import {auth} from "../../../server/firebase";

const SignedInModal = ({currentUser, toggleModal}) => {
    return (
        <div className="loginmodal">
            <div className="overlay">
                <div className="dialog">
                    <div className="togglemodal-button-container">
                        <button onClick={toggleModal} className="togglemodal-button">&times;</button>
                    </div>
                    <div className="other-details-login">
                        <div className="login-goto-yourtrip">
                            이미 로그인된 상태입니다. MYPAGE로 가려면 <Link className="here-link" to="/mytrip">HERE</Link>을 누르세요.
                        </div>
                        <div className="sign-out-button-container">
                            <button className="signout-button" onClick={() => { auth.signOut(); toggleModal(); }}>
                                Sign out <i className="fa fa-sign-out"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SignedInModal;