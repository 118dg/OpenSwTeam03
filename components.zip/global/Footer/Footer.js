import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
    return (
        <>

                
                <div className="copyright-footer">
                    <ul className="copyright-footer-list">
                    </ul>
                </div>
                
         
        </>
    );
};

export default Footer;