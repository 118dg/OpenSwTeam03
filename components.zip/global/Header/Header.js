import React, {useContext, useState} from 'react';
import './Header.css';
import { Link, NavLink } from 'react-router-dom';
import { ModalContext } from '../../../context/modal';

const Header = () => {
    const {isModalOpen, toggleModal} = useContext(ModalContext);

    const [isExpanded, setIsExpanded ] = useState(false);

    const [isEquipmentExpanded, setIsEquipmentExpanded ] = useState(false);

    const handleMenuToggle = (e) => {
        e.preventDefault();
        setIsExpanded(!isExpanded);
    }

    const handleEquipmentToggle = (e) => {
        e.preventDefault();
        setIsEquipmentExpanded(!isEquipmentExpanded);
    }


    return (
        <div className="header">
            <div className="navlist">
                <div className="logo-container">
                    <Link to="/home" className="logo"><img alt="logo" src="logo.png(로고넣어주기)" /></Link>
                </div>
                <div className="nav-container">
                        <i
                            className="fa fa-bars"
                            aria-hidden="true"
                            onClick={e => handleMenuToggle(e)}
                        />
                    <ul className={`collapsed ${isExpanded ? "is-expanded" : ""}`}>
                        <div className="main-menu-items">
                            <li><NavLink to="/home" className="navitem">Home</NavLink></li>
                            <li><NavLink to="/about" className="navitem">Add room review</NavLink></li>

                            <li><NavLink to="/activities" className="navitem activities-nav-item">Search room review</NavLink></li>
                        </div>
                        <div className="last-menu-items">
                            <li><NavLink to="/mytrip" className="navitem activities-nav-item">Mypage</NavLink></li>
                            <li><button className={`button-login ${isExpanded ? "signin-button-is-expanded" : ""} ${isModalOpen ? 'button-login-modal-open' : ''}`}
                                        onClick={toggleModal}>
                                {isExpanded ? "Signin" : <i className="fa fa-lg fa-user"></i>}
                            </button></li>
                        </div>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Header;