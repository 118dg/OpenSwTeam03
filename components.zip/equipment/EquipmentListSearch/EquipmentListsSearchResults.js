import React, {useState} from 'react';
import './EquipmentListSearch.css';
import {addFavoriteEquipmentListToUserTrip} from "../../../server/firebase";
import _ from "underscore";
import Button from "@material-ui/core/Button";
import {Pagination} from "@material-ui/lab";

const EquipmentListsSearchResults = ({ lists, user, trip }) => {
    const [currentPage, setCurrentPage] = useState(1);

    const [favListError, setFavListError] = useState([]);
    const [favListSuccess, setFavListSuccess] = useState([]);

    const numberOfListsPerPage = 10;



    const handleChange = (event, value) => {
        setCurrentPage(value);
    };

    const indexOfLastList = currentPage * numberOfListsPerPage;
    const indexOfFirstList = indexOfLastList - numberOfListsPerPage;
    const currentLists = lists.slice(indexOfFirstList, indexOfLastList);


    const handleSetFavoriteEquipmentList = async (event, user, items, listId) => {
        event.preventDefault();
        console.log('entered handleSetFavoriteEquipmentList');
        if (trip != null || trip) {
            console.log('entered trip is not null');
            try {
                await addFavoriteEquipmentListToUserTrip(user, items);
                console.log('trip updated');
                const newFavSuccess = favListSuccess.slice() //copy the array
                newFavSuccess[listId] = 'List added to your trip successfully!' //execute the manipulations
                setFavListSuccess(newFavSuccess);
                console.log('fav success:',favListSuccess[listId]);
                window.location.href = '/mytrip';
            }
            catch (favListError) {
                const newFaveError = favListError.slice();
                newFaveError[listId] = 'Error creating adding list to trip';
                setFavListError(newFaveError);
            }
        } else {
            const newFaveError = favListError.slice();
            newFaveError[listId] = 'Create trip first!';
            setFavListError(newFaveError);
            console.log("error need to create trip first-", favListError[listId]);
            window.location.href = '/mytrip';
        }
    }


        return (
            <div className="each-list-and-button">
                
                hello
            </div>
            
        );
    }

export default EquipmentListsSearchResults;