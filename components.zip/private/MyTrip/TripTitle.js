import React from 'react';
import './MyTrip.css';
import moment from "moment";
import {deleteTripFromUser} from "../../../server/firebase";

const TripTitle = ({ trip, user }) => {
    if (trip != null) {
        const { destination } = trip;



        const deleteTripHandler = event => {
            event.preventDefault();
            deleteTripFromUser(user, trip);
        }

        return (
            <div className="trip-title-container">
                <h1>{user.displayName}님은 {destination}에 관심이 있으시군요!</h1>
                <div className="trip-metadata">
                    
                    <div>
                        <button className="delete-trip-button" onClick={event => deleteTripHandler(event)}>초기화</button>
                    </div>
                </div>
            </div>
        );
    }
};

export default TripTitle;