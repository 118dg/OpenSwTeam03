import React, {useState} from 'react';
import './MyTrip.css';
import TextField from "@material-ui/core/TextField";
import {useNotes} from "../../../hooks/useNotes";

const TripNotes = ({ user }) => {
    const [notes, setNotes] = useNotes(user);

    const [notesError, setNotesError] = useState(null);

    const clearNotesInTrip = async (event, notes) => {
        event.preventDefault();
        if (notes) {
            setNotes("");
        } else {
            setNotesError('Notes is not filled');
        }
    };

    const handleChangeNotes = (event) => {
        setNotes(event.target.value);
    };

    return (
        <div className="notescontainer">
            
        </div>
    );
};

export default TripNotes;