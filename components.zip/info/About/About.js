import React from 'react';
import './About.css';
import * as firebase from 'firebase';
import firestore from 'firebase/firestore';



const About = () => {
    return (
        <div className="about">
            <div className="background">
                <div className="container">
                    <div className="title">
                        Add your review!
                    </div>
                </div>
            </div>
            <div className="contentcontainer">
                <div className="content-first-part">
                </div>
                <div className="content-second-part">                   
                </div>
            </div>
        </div>
    );
};

export default About;