import React from 'react';
import './Contact.css';

const Contact = () => {
    return (
        <div className="contact">
            <div className="background">
                <div className="container">
                    <div className="title">
                        룸메이트 등록
                    </div>
                </div>
            </div>
            <div className="contentcontainer">
                룸메이트 등록하는 사이트 제작 form 할것

            </div>
        </div>
    );
};

export default Contact;