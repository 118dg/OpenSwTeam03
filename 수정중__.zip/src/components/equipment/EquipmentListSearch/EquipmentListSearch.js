import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import './EquipmentListSearch.css';
import { searchPublicEquipmentListDocuments } from './../../../server/firebase';
import { UserContext } from './../../../context/user';
import { countries } from './../../../server/countries';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { ThemeProvider, makeStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import Loading from './../../global/Loading';
import {myTheme} from './../../../themes/myTheme';
import EquipmentListsSearchResults from "./EquipmentListsSearchResults";

const EquipmentListSearch = () => {
    const {currentUser} = useContext(UserContext);

    const [destination, setDestination] = useState("");
    const [season, setSeason] = useState("");
    const [category, setCategory] = useState("");
    const [searchError, setSearchError] = useState(null);
    const [resultsLists, setResultLists] = useState("");

    const trip = (currentUser && currentUser.trip) ? currentUser.trip : null;

    var equipmentListsResults;

    const useStyles = makeStyles(theme => ({
        option: {
            fontSize: 14,
        },
        selectRoot: {
            textAlign: "left",
        },
    }));

    const classes = useStyles();

    // get default search results- all database
    useEffect(() => {
        async function fetchData() {
            try {
                equipmentListsResults = await searchPublicEquipmentListDocuments(destination, season, category);
                setResultLists(equipmentListsResults);
            }
            catch (searchError) {
                setSearchError('Error fetching public equipment lists');
            }
        }

        fetchData();

    }, [currentUser]);

    const handleChangeSeason = (event) => {
        setSeason(event.target.value);
    };

    const handleChangeCategory = (event) => {
        setCategory(event.target.value);
    };

    const searchPublicEquipmentListDB = async (event, destination, season, category, setResultLists) => {
        event.preventDefault();
        try {
            equipmentListsResults = await searchPublicEquipmentListDocuments(destination, season, category);
            setResultLists(equipmentListsResults);
        }
        catch (searchError) {
            setSearchError('Error searching public equipment lists');
        }

        setDestination("");
        setSeason("");
        setCategory("");
    };

    return (
        <ThemeProvider theme={myTheme}>
            <div className="equipmentlistsearch">
                <div className="background">
                    <div className="container">
                        <div className="title">
                            건물/방 후기(ROOM REVIEW)
                        </div>
                        <div className="formcontainer">
                            <form className="el-search-form"
                                  onSubmit={event => {
                                      searchPublicEquipmentListDB(event, destination, season, category, setResultLists);
                                  }}>
                                <div className="destination-input">
                                    <Autocomplete
                                        style={{ width: 300 }}
                                        inputValue={destination}
                                        onInputChange={(event, newDestination) => {
                                            setDestination(newDestination);
                                        }}
                                        options={countries}
                                        classes={{
                                            option: classes.option,
                                        }}
                                        autoHighlight
                                        getOptionLabel={(option) => option.label}
                                        renderOption={(option) => (
                                            <>
                                                {option.label}
                                            </>
                                        )}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="방 타입"
                                                variant="outlined"
                                                inputProps={{
                                                    ...params.inputProps,
                                                    autoComplete: 'new-password', // disable autocomplete and autofill
                                                    classes: {
                                                        root: classes.outlinedRoot
                                                    },
                                                }}
                                            />
                                        )}
                                    />
                                </div>
                                <div className="season-input">
                                    <TextField
                                        id="outlined-select-season"
                                        select
                                        label="가격대"
                                        value={season}
                                        style={{ width: 180 }}
                                        onChange={handleChangeSeason}
                                        variant="outlined"
                                        InputProps={{
                                            classes: {
                                                root: classes.selectRoot,
                                            }
                                        }}
                                    >
                            <MenuItem value=''>
                                전체
                            </MenuItem>
                            <MenuItem value='30만원-40만원'>
                                30만원-40만원
                            </MenuItem>
                            <MenuItem value='41만원-50만원'>
                            41만원-50만원
                            </MenuItem>
                            <MenuItem value='51만원-60만원'>
                            51만원-60만원
                            </MenuItem>
                            <MenuItem value='61만원-70만원'>
                            61만원-70만원
                            </MenuItem>
                                    </TextField>
                                </div>
                                <div className="category-input">
                                    <TextField
                                        id="outlined-select-category"
                                        select
                                        label="평점"
                                        value={category}
                                        style={{ width: 180, paddingTop: 0 }}
                                        onChange={handleChangeCategory}
                                        variant="outlined"
                                        InputProps={{
                                            classes: {
                                                root: classes.selectRoot,
                                            }
                                        }}
                                    >
                            <MenuItem value=''>
                                매우불만족
                            </MenuItem>
                            <MenuItem value='1'>
                                1
                            </MenuItem>
                            <MenuItem value='2'>
                                2
                            </MenuItem>
                            <MenuItem value='3'>
                               3
                            </MenuItem>
                            <MenuItem value='3'>
                               4
                            </MenuItem>
                            <MenuItem value='3'>
                               5
                            </MenuItem>
                                    </TextField>
                                </div>
                                <div>
                                    <button
                                        className="el-search-button"
                                        type="submit">
                                        Search</button>
                                    {searchError &&
                                    <div className="error-no-search">
                                        <i className="fa fa-large fa-exclamation-circle"></i> {searchError}
                                    </div>
                                    }
                                </div>
                            </form>
                            <div className="goto-ownlist">
                                 내 후기 등록하기<Link className="goto-ownlist-link" to="/personalequipmentlist"> GO</Link>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="contentcontainer">
                    <div className="resultscontainer">
                        <div className="results-title">
                            <h4>Search Results</h4>
                        </div>
                        {resultsLists ? <EquipmentListsSearchResults lists={resultsLists} user={currentUser} trip={trip} />
                            :
                            <Loading />}
                    </div>
                </div>
            </div>
        </ThemeProvider>
    );
};

export default EquipmentListSearch;