import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
    return (
        <>
            <div className="container"></div>
            <div className="footer">
                <div className="main-footer">
                    <div className="footer-col col1">
                        <h2 className="footer-headline">Footer.js에서 수정함</h2>
                    </div>
                    <div className="footer-col col2">
                        <ul className="list-footer">
                            <li><h2 className="footer-headline">Sitemap으로 수정해줄것</h2></li>
                            <li><Link className="footer-link" to="/about">About</Link></li>
                            <li><Link className="footer-link" to="/contact">Contact Us</Link></li>
                        </ul>
                    </div>
                    <div className="footer-col col3">
                        <ul className="list-footer">
                            <li className=""><h2 className="footer-headline">오소플 3조</h2></li>
                            <li><i className="fa fa-map-marker"></i><span className="footer-text"> 1</span></li>
                            <li><i className="fa fa-phone"></i><span className="footer-text"> 2</span></li>
                            <li><i className="fa fa-envelope"></i><span className="footer-text"> 3</span></li>
                        </ul>
                    </div>
                </div>
                <div className="social-footer">
                    <ul className="social-footer-list">
                        <li><a href="https://www.facebook.com/adi.nomberg" target="_blank" rel="noopener noreferrer"><i className="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/adi_nomberg" target="_blank" rel="noopener noreferrer"><i className="fa fa-twitter"></i></a></li>
                        <li><a href="https://github.com/adinomberg" target="_blank" rel="noopener noreferrer"><i className="fa fa-github"></i></a></li>
                        <li><a href="https://www.linkedin.com/in/adinomberg/" target="_blank" rel="noopener noreferrer"><i className="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div className="copyright-footer">
                    <ul className="copyright-footer-list">
                    </ul>
                </div>
            </div>
        </>
    );
};

export default Footer;